import React from "react";

export default function AdminDashboard() {
  return <h2>Trang quản trị (Admin Dashboard)</h2>;
}
