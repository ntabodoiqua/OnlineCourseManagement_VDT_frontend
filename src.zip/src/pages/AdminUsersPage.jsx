function AdminUsersPage() {
  return <h2>📋 Quản lý Người dùng</h2>;
}

export default AdminUsersPage;
