import React from "react";

export default function StudentDashboard() {
  return <h2>Trang học tập (Student Dashboard)</h2>;
}
