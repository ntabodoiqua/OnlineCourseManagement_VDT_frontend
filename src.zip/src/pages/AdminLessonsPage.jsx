function AdminLessonsPage() {
  return <h2>📝 Quản lý Bài học</h2>;
}

export default AdminLessonsPage;
