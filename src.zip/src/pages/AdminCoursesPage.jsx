function AdminCoursesPage() {
  return <h2>📚 Quản lý Khóa học</h2>;
}

export default AdminCoursesPage;
