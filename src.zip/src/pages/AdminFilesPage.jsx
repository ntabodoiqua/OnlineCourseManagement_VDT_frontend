function AdminFilesPage() {
  return <h2>📂 Quản lý File</h2>;
}

export default AdminFilesPage;
