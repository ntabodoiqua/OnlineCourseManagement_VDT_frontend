import React from "react";

export default function InstructorDashboard() {
  return <h2>Trang quản lý khóa học (Instructor Dashboard)</h2>;
}
