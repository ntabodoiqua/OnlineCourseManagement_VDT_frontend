import RegisterForm from "../components/RegisterForm";
import "../assets/css/registerPage.css";

const RegisterPage = () => (
  <div className="register-form-bg">
    <RegisterForm />
  </div>
);

export default RegisterPage;
