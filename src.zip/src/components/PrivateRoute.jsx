import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

function PrivateRoute({ allowedRoles }) {
  const { isAuthenticated, user, isLoading } = useAuth();

  if (isLoading) return null; // hoặc spinner nếu muốn

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // 👇 Lưu ý: so sánh với giá trị như "ADMIN", "INSTRUCTOR"
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/unauthorized" replace />;
  }

  return <Outlet />;
}

export default PrivateRoute;
